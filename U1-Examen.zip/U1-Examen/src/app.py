from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def home():
  return render_template("home.html")

@app.route("/personal")
def personal():
  return render_template("personal.html")

@app.route("/habilidades")
def habilidades():
  return render_template("habilidades.html")

@app.route("/contacto", methods=["GET", "POST"])
def contacto():
  if request.method == "GET":
    return render_template("contacto.html")
  else:
    name = request.form["name"]
    email = request.form["email"]
    message = request.form["message"]
    # Procesar la información del formulario
    return render_template("contacto.html", success=True, name=name, email=email, message=message)

if __name__ == "__main__":
  app.run(debug=True)
