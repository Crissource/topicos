from flask import Flask, redirect, render_template, request, flash

app = Flask(__name__)

users = []  # Lista para almacenar usuarios

@app.route("/")
def index():
    return render_template("index.html", users=users)

@app.route("/create_user", methods=["GET", "POST"])
def create_user():
    if request.method == "GET":
        return render_template("create_user.html")
    else:
        name = request.form["name"]
        lastname = request.form["lastname"]
        new_user = f"{name} {lastname}"
        users.append(new_user)
        flash(f"Usuario {new_user} creado con éxito!")
        return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)

